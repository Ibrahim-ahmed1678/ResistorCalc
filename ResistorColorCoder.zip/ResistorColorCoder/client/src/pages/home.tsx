import { ResistorCalculator } from '@/components/resistor-calculator';
import { ReferenceCharts } from '@/components/reference-charts';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-600 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">⚡</span>
              <div>
                <h1 className="text-2xl font-bold">Resistor Color Code Calculator</h1>
                <p className="text-blue-100 text-sm">Professional Electronics Tool</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#calculator" className="hover:text-blue-200 transition-colors">Calculator</a>
              <a href="#reference" className="hover:text-blue-200 transition-colors">Reference</a>
              <a href="#help" className="hover:text-blue-200 transition-colors">Help</a>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Calculator Interface */}
        <section id="calculator">
          <ResistorCalculator />
        </section>

        {/* Educational Reference Section */}
        <ReferenceCharts />

        {/* Help Section */}
        <section id="help" className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">How to Use</h2>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Reading Resistor Color Codes</h3>
                <ol className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start">
                    <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">1</span>
                    Select the number of color bands on your resistor (3, 4, 5, or 6 bands)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">2</span>
                    Click on each band in the resistor diagram to select it
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">3</span>
                    Choose the corresponding color from the color palette
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">4</span>
                    The resistance value will be calculated automatically
                  </li>
                </ol>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Tips & Troubleshooting</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2 mt-0.5">✓</span>
                    Hold the resistor so the tolerance band (gold/silver) is on the right
                  </li>
                  <li className="flex items-start">
                    <span className="text-yellow-600 mr-2 mt-0.5">💡</span>
                    Use good lighting to distinguish between similar colors
                  </li>
                  <li className="flex items-start">
                    <span className="text-blue-600 mr-2 mt-0.5">ℹ️</span>
                    Some colors may appear faded - refer to the color chart if unsure
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2 mt-0.5">⚠️</span>
                    Always verify critical values with a multimeter
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white mt-16 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">&copy; 2024 Resistor Color Code Calculator. Professional electronics tool for engineers and hobbyists.</p>
          <p className="text-sm text-gray-500 mt-2">Always verify critical resistance values with proper measurement equipment.</p>
        </div>
      </footer>
    </div>
  );
}
