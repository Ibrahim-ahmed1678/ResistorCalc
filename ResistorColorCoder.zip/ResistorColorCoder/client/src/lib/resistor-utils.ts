export interface ResistorColor {
  name: string;
  value?: number;
  multiplier?: number;
  tolerance?: number;
  color: string;
  textColor?: string;
}

export const resistorColors: Record<string, ResistorColor> = {
  black: { name: 'Black', value: 0, multiplier: 1, color: 'var(--resistor-black)', textColor: 'white' },
  brown: { name: 'Brown', value: 1, multiplier: 10, tolerance: 1, color: 'var(--resistor-brown)', textColor: 'white' },
  red: { name: 'Red', value: 2, multiplier: 100, tolerance: 2, color: 'var(--resistor-red)', textColor: 'white' },
  orange: { name: 'Orange', value: 3, multiplier: 1000, color: 'var(--resistor-orange)', textColor: 'black' },
  yellow: { name: 'Yellow', value: 4, multiplier: 10000, color: 'var(--resistor-yellow)', textColor: 'black' },
  green: { name: 'Green', value: 5, multiplier: 100000, tolerance: 0.5, color: 'var(--resistor-green)', textColor: 'white' },
  blue: { name: 'Blue', value: 6, multiplier: 1000000, tolerance: 0.25, color: 'var(--resistor-blue)', textColor: 'white' },
  violet: { name: 'Violet', value: 7, multiplier: 10000000, tolerance: 0.1, color: 'var(--resistor-violet)', textColor: 'white' },
  gray: { name: 'Gray', value: 8, multiplier: 100000000, tolerance: 0.05, color: 'var(--resistor-gray)', textColor: 'white' },
  white: { name: 'White', value: 9, multiplier: 1000000000, color: 'var(--resistor-white)', textColor: 'black' },
  gold: { name: 'Gold', multiplier: 0.1, tolerance: 5, color: 'var(--resistor-gold)', textColor: 'black' },
  silver: { name: 'Silver', multiplier: 0.01, tolerance: 10, color: 'var(--resistor-silver)', textColor: 'black' }
};

export interface ResistorBands {
  band1?: string;
  band2?: string;
  band3?: string;
  band4?: string;
  band5?: string;
  band6?: string;
}

export interface ResistorValue {
  resistance: number;
  tolerance: number;
  formattedValue: string;
  unit: string;
  minValue: number;
  maxValue: number;
  eSeries: string;
}

export function calculateResistorValue(bands: ResistorBands, bandCount: number): ResistorValue | null {
  try {
    let resistance = 0;
    let tolerance = 20; // Default tolerance
    
    if (bandCount === 3) {
      // 3-band: digit1, digit2, multiplier
      if (!bands.band1 || !bands.band2 || !bands.band3) return null;
      
      const digit1 = resistorColors[bands.band1]?.value;
      const digit2 = resistorColors[bands.band2]?.value;
      const multiplier = resistorColors[bands.band3]?.multiplier;
      
      if (digit1 === undefined || digit2 === undefined || multiplier === undefined) return null;
      
      resistance = (digit1 * 10 + digit2) * multiplier;
      tolerance = 20; // Standard tolerance for 3-band resistors
      
    } else if (bandCount === 4) {
      // 4-band: digit1, digit2, multiplier, tolerance
      if (!bands.band1 || !bands.band2 || !bands.band3 || !bands.band4) return null;
      
      const digit1 = resistorColors[bands.band1]?.value;
      const digit2 = resistorColors[bands.band2]?.value;
      const multiplier = resistorColors[bands.band3]?.multiplier;
      const toleranceValue = resistorColors[bands.band4]?.tolerance;
      
      if (digit1 === undefined || digit2 === undefined || multiplier === undefined || toleranceValue === undefined) return null;
      
      resistance = (digit1 * 10 + digit2) * multiplier;
      tolerance = toleranceValue;
      
    } else if (bandCount === 5) {
      // 5-band: digit1, digit2, digit3, multiplier, tolerance
      if (!bands.band1 || !bands.band2 || !bands.band3 || !bands.band4 || !bands.band5) return null;
      
      const digit1 = resistorColors[bands.band1]?.value;
      const digit2 = resistorColors[bands.band2]?.value;
      const digit3 = resistorColors[bands.band3]?.value;
      const multiplier = resistorColors[bands.band4]?.multiplier;
      const toleranceValue = resistorColors[bands.band5]?.tolerance;
      
      if (digit1 === undefined || digit2 === undefined || digit3 === undefined || multiplier === undefined || toleranceValue === undefined) return null;
      
      resistance = (digit1 * 100 + digit2 * 10 + digit3) * multiplier;
      tolerance = toleranceValue;
      
    } else if (bandCount === 6) {
      // 6-band: digit1, digit2, digit3, multiplier, tolerance, temperature coefficient
      if (!bands.band1 || !bands.band2 || !bands.band3 || !bands.band4 || !bands.band5) return null;
      
      const digit1 = resistorColors[bands.band1]?.value;
      const digit2 = resistorColors[bands.band2]?.value;
      const digit3 = resistorColors[bands.band3]?.value;
      const multiplier = resistorColors[bands.band4]?.multiplier;
      const toleranceValue = resistorColors[bands.band5]?.tolerance;
      
      if (digit1 === undefined || digit2 === undefined || digit3 === undefined || multiplier === undefined || toleranceValue === undefined) return null;
      
      resistance = (digit1 * 100 + digit2 * 10 + digit3) * multiplier;
      tolerance = toleranceValue;
    }
    
    const { formattedValue, unit } = formatResistance(resistance);
    const minValue = resistance * (1 - tolerance / 100);
    const maxValue = resistance * (1 + tolerance / 100);
    const eSeries = getESeries(tolerance);
    
    return {
      resistance,
      tolerance,
      formattedValue,
      unit,
      minValue,
      maxValue,
      eSeries
    };
  } catch (error) {
    return null;
  }
}

export function formatResistance(resistance: number): { formattedValue: string; unit: string } {
  if (resistance >= 1000000) {
    return {
      formattedValue: (resistance / 1000000).toString(),
      unit: 'MΩ'
    };
  } else if (resistance >= 1000) {
    return {
      formattedValue: (resistance / 1000).toString(),
      unit: 'kΩ'
    };
  } else {
    return {
      formattedValue: resistance.toString(),
      unit: 'Ω'
    };
  }
}

export function getESeries(tolerance: number): string {
  if (tolerance <= 0.05) return 'E192';
  if (tolerance <= 0.1) return 'E96';
  if (tolerance <= 0.25) return 'E48';
  if (tolerance <= 0.5) return 'E48';
  if (tolerance <= 1) return 'E24';
  if (tolerance <= 2) return 'E24';
  if (tolerance <= 5) return 'E12';
  if (tolerance <= 10) return 'E6';
  return 'E3';
}

export function findColorCombination(targetValue: number, tolerance: number = 5): ResistorBands | null {
  // Try 4-band first (most common)
  for (const [color1, data1] of Object.entries(resistorColors)) {
    if (data1.value === undefined) continue;
    for (const [color2, data2] of Object.entries(resistorColors)) {
      if (data2.value === undefined) continue;
      for (const [color3, data3] of Object.entries(resistorColors)) {
        if (data3.multiplier === undefined) continue;
        
        const calculatedValue = (data1.value * 10 + data2.value) * data3.multiplier;
        if (Math.abs(calculatedValue - targetValue) < targetValue * 0.01) {
          // Find appropriate tolerance band
          const toleranceBand = Object.entries(resistorColors).find(([, data]) => 
            data.tolerance === tolerance
          )?.[0] || 'gold';
          
          return {
            band1: color1,
            band2: color2,
            band3: color3,
            band4: toleranceBand
          };
        }
      }
    }
  }
  
  return null;
}

export function getBandLabel(bandIndex: number, bandCount: number): string {
  if (bandCount === 3) {
    switch (bandIndex) {
      case 1: return 'First Digit';
      case 2: return 'Second Digit';
      case 3: return 'Multiplier';
      default: return '';
    }
  } else if (bandCount === 4) {
    switch (bandIndex) {
      case 1: return 'First Digit';
      case 2: return 'Second Digit';
      case 3: return 'Multiplier';
      case 4: return 'Tolerance';
      default: return '';
    }
  } else if (bandCount === 5) {
    switch (bandIndex) {
      case 1: return 'First Digit';
      case 2: return 'Second Digit';
      case 3: return 'Third Digit';
      case 4: return 'Multiplier';
      case 5: return 'Tolerance';
      default: return '';
    }
  } else if (bandCount === 6) {
    switch (bandIndex) {
      case 1: return 'First Digit';
      case 2: return 'Second Digit';
      case 3: return 'Third Digit';
      case 4: return 'Multiplier';
      case 5: return 'Tolerance';
      case 6: return 'Temp Coeff';
      default: return '';
    }
  }
  return '';
}
