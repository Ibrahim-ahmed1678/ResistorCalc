import { ResistorBands, resistorColors } from '@/lib/resistor-utils';

interface ResistorVisualizationProps {
  bands: ResistorBands;
  bandCount: number;
  activeBand: number;
  onBandClick: (bandIndex: number) => void;
}

export function ResistorVisualization({ bands, bandCount, activeBand, onBandClick }: ResistorVisualizationProps) {
  const getBandColor = (bandKey: keyof ResistorBands) => {
    const colorKey = bands[bandKey];
    return colorKey ? resistorColors[colorKey]?.color || '#e5e7eb' : '#e5e7eb';
  };

  const getBandPosition = (bandIndex: number) => {
    const positions = {
      3: { 1: 48, 2: 64, 3: 80 },
      4: { 1: 48, 2: 64, 3: 80, 4: 256 },
      5: { 1: 48, 2: 64, 3: 80, 4: 96, 5: 256 },
      6: { 1: 48, 2: 64, 3: 80, 4: 96, 5: 256, 6: 272 },
    };
    return positions[bandCount as keyof typeof positions]?.[bandIndex as keyof typeof positions[3]] || 0;
  };

  const renderBand = (bandIndex: number, bandKey: keyof ResistorBands) => {
    const isActive = activeBand === bandIndex;
    const position = getBandPosition(bandIndex);
    
    return (
      <div
        key={bandIndex}
        className={`absolute top-0 w-6 h-full cursor-pointer transition-all duration-200 hover:opacity-80 border-r border-black ${
          isActive ? 'ring-2 ring-blue-500 ring-offset-2' : ''
        }`}
        style={{
          left: `${position}px`,
          backgroundColor: getBandColor(bandKey),
        }}
        onClick={() => onBandClick(bandIndex)}
        title={`Band ${bandIndex}: ${resistorColors[bands[bandKey] || '']?.name || 'Select Color'}`}
      />
    );
  };

  return (
    <div className="flex justify-center items-center py-8">
      <div className="relative">
        {/* Resistor Body */}
        <div className="w-80 h-16 bg-yellow-100 rounded-lg border-2 border-gray-300 relative overflow-hidden">
          {/* Lead wires */}
          <div className="absolute -left-4 top-1/2 transform -translate-y-1/2 w-4 h-1 bg-gray-400"></div>
          <div className="absolute -right-4 top-1/2 transform -translate-y-1/2 w-4 h-1 bg-gray-400"></div>
          
          {/* Color Bands */}
          {bandCount >= 3 && (
            <>
              {renderBand(1, 'band1')}
              {renderBand(2, 'band2')}
              {renderBand(3, 'band3')}
            </>
          )}
          
          {bandCount >= 4 && renderBand(4, 'band4')}
          {bandCount >= 5 && renderBand(5, 'band5')}
          {bandCount >= 6 && renderBand(6, 'band6')}
        </div>
      </div>
    </div>
  );
}
