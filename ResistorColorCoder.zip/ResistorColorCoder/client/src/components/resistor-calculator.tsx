import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ResistorVisualization } from './resistor-visualization';
import { ColorPalette } from './color-palette';
import { ResultsDisplay } from './results-display';
import { ReverseLookup } from './reverse-lookup';
import { ResistorBands, calculateResistorValue } from '@/lib/resistor-utils';

export function ResistorCalculator() {
  const [bandCount, setBandCount] = useState(4);
  const [activeBand, setActiveBand] = useState(1);
  const [bands, setBands] = useState<ResistorBands>({
    band1: 'brown',
    band2: 'red',
    band3: 'orange',
    band4: 'gold'
  });

  const result = calculateResistorValue(bands, bandCount);

  const handleBandCountChange = (count: number) => {
    setBandCount(count);
    setActiveBand(1);
    
    // Reset bands based on count
    const newBands: ResistorBands = {};
    if (count >= 3) {
      newBands.band1 = 'brown';
      newBands.band2 = 'red';
      newBands.band3 = 'orange';
    }
    if (count >= 4) {
      newBands.band4 = 'gold';
    }
    if (count >= 5) {
      newBands.band5 = 'gold';
    }
    if (count >= 6) {
      newBands.band6 = 'brown';
    }
    
    setBands(newBands);
  };

  const handleColorSelect = (color: string) => {
    const bandKey = `band${activeBand}` as keyof ResistorBands;
    setBands(prev => ({
      ...prev,
      [bandKey]: color
    }));
    
    // Auto-advance to next band
    if (activeBand < bandCount) {
      setActiveBand(activeBand + 1);
    }
  };

  const handleReverseLookupResult = (newBands: ResistorBands) => {
    setBands(newBands);
    setBandCount(4); // Default to 4-band for reverse lookup
  };

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Main Calculator Section */}
      <div className="lg:col-span-2 space-y-6">
        {/* Band Configuration Selection */}
        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Resistor Configuration</h2>
            <div className="flex flex-wrap gap-2">
              {[3, 4, 5, 6].map(count => (
                <Button
                  key={count}
                  variant={bandCount === count ? "default" : "outline"}
                  onClick={() => handleBandCountChange(count)}
                  className={bandCount === count ? "bg-blue-600 hover:bg-blue-700" : ""}
                >
                  {count}-Band
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Visual Resistor Display */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Resistor Visualization</h3>
            <ResistorVisualization
              bands={bands}
              bandCount={bandCount}
              activeBand={activeBand}
              onBandClick={setActiveBand}
            />
          </CardContent>
        </Card>

        {/* Color Selection Interface */}
        <ColorPalette
          activeBand={activeBand}
          bandCount={bandCount}
          onColorSelect={handleColorSelect}
        />
      </div>

      {/* Results and Tools Sidebar */}
      <div className="space-y-6">
        <ResultsDisplay result={result} />
        <ReverseLookup onColorCombinationFound={handleReverseLookupResult} />
        
        {/* Quick Reference */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
              <span className="mr-2">❓</span>
              Quick Reference
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: 'var(--resistor-gold)' }}></div>
                <span>Gold = ±5% tolerance</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 rounded border" style={{ backgroundColor: 'var(--resistor-silver)' }}></div>
                <span>Silver = ±10% tolerance</span>
              </div>
              <div className="pt-2 border-t">
                <p className="text-gray-600">3rd band = multiplier (×10ⁿ)</p>
                <p className="text-gray-600">4th band = tolerance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
