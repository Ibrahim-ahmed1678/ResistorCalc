import { resistorColors } from '@/lib/resistor-utils';
import { Card, CardContent } from '@/components/ui/card';

export function ReferenceCharts() {
  const valueColors = Object.entries(resistorColors).filter(([, data]) => data.value !== undefined);
  const multiplierColors = Object.entries(resistorColors).filter(([, data]) => data.multiplier !== undefined);
  const toleranceColors = Object.entries(resistorColors).filter(([, data]) => data.tolerance !== undefined);

  return (
    <section id="reference" className="mt-12">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Color Code Reference</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {/* Color Value Chart */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Color Values</h3>
            <div className="space-y-2">
              {valueColors.map(([colorKey, colorData]) => (
                <div key={colorKey} className="flex items-center justify-between py-2 border-b border-gray-100">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-6 h-6 rounded border border-gray-300"
                      style={{ backgroundColor: colorData.color }}
                    />
                    <span className="font-medium">{colorData.name}</span>
                  </div>
                  <span className="text-gray-600">{colorData.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Multiplier Chart */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Multipliers</h3>
            <div className="space-y-2">
              {multiplierColors.map(([colorKey, colorData]) => {
                let multiplierText = '';
                if (colorData.multiplier! >= 1000000000) {
                  multiplierText = `×${colorData.multiplier! / 1000000000} GΩ`;
                } else if (colorData.multiplier! >= 1000000) {
                  multiplierText = `×${colorData.multiplier! / 1000000} MΩ`;
                } else if (colorData.multiplier! >= 1000) {
                  multiplierText = `×${colorData.multiplier! / 1000} kΩ`;
                } else if (colorData.multiplier! >= 1) {
                  multiplierText = `×${colorData.multiplier} Ω`;
                } else {
                  multiplierText = `×${colorData.multiplier} Ω`;
                }

                return (
                  <div key={colorKey} className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div className="flex items-center space-x-3">
                      <div 
                        className="w-6 h-6 rounded border border-gray-300"
                        style={{ backgroundColor: colorData.color }}
                      />
                      <span className="font-medium">{colorData.name}</span>
                    </div>
                    <span className="text-gray-600">{multiplierText}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Tolerance Chart */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Tolerance</h3>
            <div className="space-y-2">
              {toleranceColors.map(([colorKey, colorData]) => (
                <div key={colorKey} className="flex items-center justify-between py-2 border-b border-gray-100">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-6 h-6 rounded border border-gray-300"
                      style={{ backgroundColor: colorData.color }}
                    />
                    <span className="font-medium">{colorData.name}</span>
                  </div>
                  <span className="text-gray-600">±{colorData.tolerance}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
