import { ResistorValue } from '@/lib/resistor-utils';
import { Card, CardContent } from '@/components/ui/card';

interface ResultsDisplayProps {
  result: ResistorValue | null;
}

export function ResultsDisplay({ result }: ResultsDisplayProps) {
  if (!result) {
    return (
      <Card>
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🔢</span>
            Calculated Value
          </h3>
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div className="text-xl font-bold text-gray-500">Select Colors</div>
            <div className="text-sm text-gray-400 mt-1">Choose band colors to calculate resistance</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { formattedValue, unit, tolerance, minValue, maxValue, eSeries } = result;
  const minFormatted = minValue >= 1000000 ? (minValue / 1000000).toFixed(2) + ' MΩ' :
                      minValue >= 1000 ? (minValue / 1000).toFixed(2) + ' kΩ' :
                      minValue.toFixed(1) + ' Ω';
  const maxFormatted = maxValue >= 1000000 ? (maxValue / 1000000).toFixed(2) + ' MΩ' :
                      maxValue >= 1000 ? (maxValue / 1000).toFixed(2) + ' kΩ' :
                      maxValue.toFixed(1) + ' Ω';

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="mr-2">🔢</span>
          Calculated Value
        </h3>
        <div className="space-y-4">
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-3xl font-bold text-green-800">
              {formattedValue} {unit}
            </div>
            <div className="text-sm text-green-600 mt-1">
              {result.resistance.toLocaleString()} Ohms
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="p-3 bg-gray-50 rounded">
              <div className="text-gray-600">Tolerance</div>
              <div className="font-semibold">±{tolerance}%</div>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <div className="text-gray-600">E-Series</div>
              <div className="font-semibold">{eSeries}</div>
            </div>
          </div>

          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="text-xs text-blue-600 uppercase tracking-wide mb-1">Value Range</div>
            <div className="text-sm font-medium text-blue-800">
              {minFormatted} - {maxFormatted}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
