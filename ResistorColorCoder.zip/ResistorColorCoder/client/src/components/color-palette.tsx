import { resistorColors, getBandLabel } from '@/lib/resistor-utils';
import { Button } from '@/components/ui/button';

interface ColorPaletteProps {
  activeBand: number;
  bandCount: number;
  onColorSelect: (color: string) => void;
}

export function ColorPalette({ activeBand, bandCount, onColorSelect }: ColorPaletteProps) {
  const getAvailableColors = () => {
    // For tolerance bands (last band), only show tolerance colors
    const isToleranceBand = (bandCount === 4 && activeBand === 4) || 
                           (bandCount === 5 && activeBand === 5) || 
                           (bandCount === 6 && activeBand === 5);
    
    if (isToleranceBand) {
      return Object.entries(resistorColors).filter(([, data]) => data.tolerance !== undefined);
    }
    
    // For multiplier bands, show all colors with multiplier values
    const isMultiplierBand = (bandCount === 3 && activeBand === 3) ||
                            (bandCount === 4 && activeBand === 3) ||
                            (bandCount === 5 && activeBand === 4) ||
                            (bandCount === 6 && activeBand === 4);
    
    if (isMultiplierBand) {
      return Object.entries(resistorColors).filter(([, data]) => data.multiplier !== undefined);
    }
    
    // For digit bands, show colors with digit values
    return Object.entries(resistorColors).filter(([, data]) => data.value !== undefined);
  };

  const availableColors = getAvailableColors();

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Select Band Colors</h3>
      
      {/* Active Band Indicator */}
      <div className="mb-4 p-3 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800 flex items-center">
          <span className="mr-2">ℹ️</span>
          Currently selecting: <span className="font-semibold ml-1">
            {getBandLabel(activeBand, bandCount)}
          </span>
        </p>
      </div>

      {/* Color Grid */}
      <div className="grid grid-cols-6 sm:grid-cols-12 gap-3">
        {availableColors.map(([colorKey, colorData]) => (
          <Button
            key={colorKey}
            variant="outline"
            className="w-12 h-12 p-0 border-2 hover:border-gray-600 transition-all hover:scale-105"
            style={{ backgroundColor: colorData.color }}
            onClick={() => onColorSelect(colorKey)}
            title={`${colorData.name} ${colorData.value !== undefined ? `(${colorData.value})` : ''} ${colorData.tolerance !== undefined ? `(±${colorData.tolerance}%)` : ''}`}
          />
        ))}
      </div>
    </div>
  );
}
