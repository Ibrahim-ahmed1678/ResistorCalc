import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { findColorCombination, ResistorBands, resistorColors } from '@/lib/resistor-utils';

interface ReverseLookupProps {
  onColorCombinationFound: (bands: ResistorBands) => void;
}

export function ReverseLookup({ onColorCombinationFound }: ReverseLookupProps) {
  const [inputValue, setInputValue] = useState('');
  const [unit, setUnit] = useState('Ω');
  const [tolerance, setTolerance] = useState('5');
  const [result, setResult] = useState<ResistorBands | null>(null);

  const handleLookup = () => {
    const numericValue = parseFloat(inputValue);
    if (isNaN(numericValue) || numericValue <= 0) return;

    let targetValue = numericValue;
    if (unit === 'kΩ') targetValue *= 1000;
    if (unit === 'MΩ') targetValue *= 1000000;

    const colorCombination = findColorCombination(targetValue, parseFloat(tolerance));
    if (colorCombination) {
      setResult(colorCombination);
      onColorCombinationFound(colorCombination);
    } else {
      setResult(null);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="mr-2">🔍</span>
          Reverse Lookup
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter Resistance Value
            </label>
            <div className="flex space-x-2">
              <Input
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="12000"
                className="flex-1"
              />
              <Select value={unit} onValueChange={setUnit}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ω">Ω</SelectItem>
                  <SelectItem value="kΩ">kΩ</SelectItem>
                  <SelectItem value="MΩ">MΩ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tolerance
            </label>
            <Select value={tolerance} onValueChange={setTolerance}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">±5% (Gold)</SelectItem>
                <SelectItem value="10">±10% (Silver)</SelectItem>
                <SelectItem value="1">±1% (Brown)</SelectItem>
                <SelectItem value="2">±2% (Red)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleLookup}
            className="w-full bg-teal-600 hover:bg-teal-700"
          >
            Find Color Code
          </Button>

          {result && (
            <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="text-sm font-medium text-green-800 mb-2">Found Color Code:</div>
              <div className="flex gap-2">
                {Object.entries(result).map(([bandKey, colorKey]) => {
                  if (!colorKey) return null;
                  const color = resistorColors[colorKey];
                  return (
                    <div key={bandKey} className="flex flex-col items-center">
                      <div 
                        className="w-6 h-6 rounded border border-gray-300"
                        style={{ backgroundColor: color.color }}
                        title={color.name}
                      />
                      <span className="text-xs mt-1">{color.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
